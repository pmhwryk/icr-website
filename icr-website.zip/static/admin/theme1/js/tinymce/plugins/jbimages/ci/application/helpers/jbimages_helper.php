<?php
/* 	
	This Helper is a wrapper of the file below
*/

include("../is_allowed.php");
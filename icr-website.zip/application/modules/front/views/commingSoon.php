    <!-- Start Main Banner Area -->
    <style>
        html, body{
            margin: 0;
        }
        .title{
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            font-size: 75px;
            text-transform: uppercase;
            color: black;
            text-shadow: 3px 1px white;
            letter-spacing: 7px;
        }
    </style>
    <div class="main-banner main-banner-one">
        <div class="container-fluid" style="width: 100%; height: 100vh; background-position: center; background-size: contain; background-repeat: no-repeat; background-image: url(<?=STATIC_FRONT_IMAGE?>19.jpg);">
            <!-- <h1 class="title">Comming Soon</h1> -->
        </div>
    </div>
    <!-- End Main Banner Area -->
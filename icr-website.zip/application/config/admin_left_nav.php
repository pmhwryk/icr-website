<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
$config = array(
	'modules' =>  array(
		 1  => 'dashboard',
		 2  => 'outlet',
		 3  => 'general_setting',
		 4  => 'users',
		 5  => 'roles',
		 6  => 'permission',
		 8  => 'orders',
		 9 => 'customers',
		 10 => 'postcode',
		 11 => 'timing',
		 12 => 'driver'
		
	),
);
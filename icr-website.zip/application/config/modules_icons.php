<?php 
$config = array('module_icons' => array('dashboard' => 'home.png', 'webpages' => 'page.png', 'outlet' =>
'outlet.png', 'catagories' => 'categories.png', 'general_setting' => 'setting.png', 'users' => 'users.png','booking' =>
'roles.png', 'pakke' =>
'roles.png','roles' =>
'roles.png', 'permission' => 'security.png', 'post' => 'hr.png', 'multimedia' => 'hr.png', 'news' => 'hr.png',
),
'module_icons_hover' => array('dashboard' => 'home_colored.png', 'webpages' => 'page_hover.png', 
'outlet' => 'outlet_colored.png', 'catagories' => 'categories_colored.png', 'general_setting' => 'setting_colored.png',
'users' => 'users.png', 'booking' => 'roles_colored.png', 'pakke' => 'roles_colored.png','roles' => 'roles_colored.png', 'permission' => 'security_colored.png', 'multimedia' => 'hr.png', 'news' => 'hr.png', 'banner_management' => 'hr.png'));
?>